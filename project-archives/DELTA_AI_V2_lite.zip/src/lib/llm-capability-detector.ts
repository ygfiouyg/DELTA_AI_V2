/**
 * LLM Capability Detector — V.69
 * ═══════════════════════════════════════════════════════════════════════
 *
 * بدل regex، الموديل نفسه بيحلل الطلب ويقرر:
 * 1. هل المحتوى المطلوب محتاج أداة خاصة؟
 * 2. لو أيه، إيه الأداة المطلوبة؟
 * 3. هل الأداة متاحة محلياً؟
 * 4. لو مش متاحة → ابحث وثبتها
 *
 * ده "thinking outside the box" — الموديل بيفكر مش بيـ pattern match
 */

import { getAvailableTools } from './autonomous-agent';

export interface LLMCapabilityAnalysis {
  needsSpecialTool: boolean;
  toolName: string;
  toolType: 'pip' | 'npm' | 'docker' | 'local' | 'system';
  installCommand: string;
  githubSearchQuery: string;
  reason: string;
  hasToolLocally: boolean;
  // V.72: Multi-tool support
  allTools?: Array<{
    name: string;
    type: string;
    purpose: string;
    available: boolean;
  }>;
  // V.93: Format matching — إيه الـ format المطلوب بالظبط
  requestedFormat?: string; // 'pdf' | 'pptx' | 'xlsx' | 'docx' | 'mp3' | 'mp4' | 'png' | 'csv' | 'json' | 'text' | 'python_code' | 'chart' | 'none'
  requestedAction?: string; // وصف العملية المطلوبة
  shouldGenerateFile?: boolean; // هل المفروض يولّد ملف؟
}

/**
 * Ask the LLM to analyze a user request and determine if a special tool is needed
 */
export async function analyzeCapabilityWithLLM(
  userMessage: string,
  language: 'ar' | 'en' = 'ar'
): Promise<LLMCapabilityAnalysis> {
  // First, get available tools
  const availableTools = await getAvailableTools();

  const prompt = `أنت محلل قدرات ذكي. حلل طلب المستخدم التالي وحدد:

1. هل الطلب يحتاج أداة خاصة غير المحادثة العادية؟
2. لو أيه، إيه **كل** الأدوات المطلوبة (ممكن يكون أكثر من أداة)؟
3. إيه نوع التثبيت لكل أداة؟ (pip, npm, docker, local, system)
4. إيه أمر التثبيت لكل أداة؟
5. إيه استعلام البحث في GitHub؟
6. **إيه الـ format المطلوب بالظبط؟** (pdf, pptx, xlsx, docx, mp3, mp4, png, csv, json, text, python_code, chart, none)
7. هل المفروض يولّد ملف؟

الأدوات المتاحة حالياً: ${availableTools.join(', ')}

طلب المستخدم: "${userMessage}"

أجب بصيغة JSON فقط:
{
  "needsSpecialTool": true/false,
  "toolName": "الأداة الرئيسية أو فارغ",
  "toolType": "pip|npm|docker|local|system",
  "installCommand": "أمر التثبيت الرئيسي أو فارغ",
  "githubSearchQuery": "استعلام البحث أو فارغ",
  "reason": "السبب",
  "hasToolLocally": true/false,
  "requestedFormat": "pdf|pptx|xlsx|docx|mp3|mp4|png|csv|json|text|python_code|chart|none",
  "requestedAction": "وصف العملية المطلوبة",
  "shouldGenerateFile": true/false,
  "allTools": [
    {"name": "pytube", "type": "pip", "purpose": "تنزيل الفيديو", "available": false},
    {"name": "pydub", "type": "pip", "purpose": "استخراج الصوت", "available": false},
    {"name": "SpeechRecognition", "type": "pip", "purpose": "تحويل الصوت لنص", "available": false}
  ]
}

قواعد مهمة:
- لو الطلب معقد ويحتاج خطوات متعددة → حط كل الأدوات في allTools
- مثلاً "حمّل فيديو من يوتيوب وحول الصوت لنص" يحتاج: pytube + pydub + SpeechRecognition
- مثلاً "اقرأ صورة وحولها لـ PDF" يحتاج: pytesseract + pillow + pymupdf
- مثلاً "استخرج صور من PDF واعمل عرض تقديمي" يحتاج: pymupdf + pillow + python-pptx
- مثلاً "تحليل فني لـ Bitcoin مع RSI و MACD" يحتاج: yfinance + pandas + ta + matplotlib
- مثلاً "رسم بياني للأسعار" يحتاج: matplotlib + yfinance (رسم بياني ≠ صورة!)
- مثلاً "اعمل كود QR" يحتاج: qrcode
- مثلاً "حول PDF لصوت" يحتاج: pymupdf + gtts
- لو الأداة في قائمة الأدوات المتاحة → available: true
- لو الأداة Python stdlib (مثل os, json, smtplib) → available: true, type: "system"
- لو الطلب محادثة عادية → needsSpecialTool: false, allTools: []
- لو الطلب تحليل بيانات أو رسم بياني → ده كود Python مش توليد صورة!
- toolName = الأداة الأولى في allTools (الأهم)

**قواعد Format Matching (مهمة جداً):**
- لو المستخدم قال "PowerPoint" أو "باوربوينت" أو "ppt" → requestedFormat: "pptx" (مش PDF!)
- لو المستخدم قال "Excel" أو "اكسل" أو "xlsx" → requestedFormat: "xlsx"
- لو المستخدم قال "PDF" أو "بي دي اف" → requestedFormat: "pdf"
- لو المستخدم قال "Word" أو "وورد" أو "docx" → requestedFormat: "docx"
- لو المستخدم قال "MP3" أو "ملف صوتي" أو "صوت" → requestedFormat: "mp3"
- لو المستخدم قال "رسم بياني" أو "chart" أو "مخطط" → requestedFormat: "chart"
- لو المستخدم قال "صورة" أو "ارسم" → requestedFormat: "png"
- لو المستخدم قال "تحليل" أو "حساب" بدون ما يطلب ملف → requestedFormat: "python_code"
- لو المستخدم بيسأل سؤال → requestedFormat: "none", shouldGenerateFile: false
- **ممنوع تستبدل format بـ format تاني!** لو طلب PowerPoint → اعمل pptx فقط، مش PDF.`;

  try {
    const { getZAIClient } = await import('./chat-utils');
    const zai = await getZAIClient();

    const result = await zai.chat.completions.create({
      model: 'glm-4-flash',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.0,
      max_tokens: 600,
    });

    const content = result.choices?.[0]?.message?.content || '';

    // Parse JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return defaultAnalysis();
    }

    const parsed = JSON.parse(jsonMatch[0]);

    const toolName = parsed.toolName || '';

    // V.76: NEVER trust the LLM's hasToolLocally — ALWAYS verify for real!
    // The LLM was saying "available: true" for sympy even though it's NOT installed.
    let hasToolLocally = false;

    // Check ALL tools from LLM response (allTools array)
    const allTools = parsed.allTools || [];
    if (allTools.length > 0) {
      for (const t of allTools) {
        t.available = false; // Reset — don't trust LLM
        const modName = t.name.replace(/-/g, '_').toLowerCase();
        try {
          const { exec } = await import('child_process');
          const { promisify } = await import('util');
          const execAsync = promisify(exec);
          const { stdout } = await execAsync(`python3 -c "import ${modName}; print('OK')"`, { timeout: 5_000 });
          if (stdout.includes('OK')) {
            t.available = true;
            console.log(`[LLMCapability] V.76: ${t.name} verified as available`);
          }
        } catch {
          // Not available — needs install
          console.log(`[LLMCapability] V.76: ${t.name} NOT available — needs install`);
        }
      }
      // Set main tool availability
      hasToolLocally = allTools[0]?.available || false;
    }

    // Also check the main toolName directly
    if (!hasToolLocally && toolName) {
      const modName = toolName.replace(/-/g, '_').toLowerCase();
      try {
        const { exec } = await import('child_process');
        const { promisify } = await import('util');
        const execAsync = promisify(exec);
        const { stdout } = await execAsync(`python3 -c "import ${modName}; print('OK')"`, { timeout: 5_000 });
        if (stdout.includes('OK')) {
          hasToolLocally = true;
          console.log(`[LLMCapability] V.76: ${toolName} verified as available (main tool)`);
        }
      } catch {
        // Not available
      }
    }

    // Also check against our known available tools list
    if (!hasToolLocally && availableTools.includes(toolName)) {
      hasToolLocally = true;
    }

    return {
      needsSpecialTool: parsed.needsSpecialTool || false,
      toolName,
      toolType: parsed.toolType || 'pip',
      installCommand: parsed.installCommand || '',
      githubSearchQuery: parsed.githubSearchQuery || '',
      reason: parsed.reason || '',
      hasToolLocally,
      allTools,
      // V.93: Format matching
      requestedFormat: parsed.requestedFormat || 'none',
      requestedAction: parsed.requestedAction || '',
      shouldGenerateFile: parsed.shouldGenerateFile || false,
    };
  } catch (error) {
    console.warn('[LLMCapability] Analysis failed:', error instanceof Error ? error.message : String(error));
    return defaultAnalysis();
  }
}

function defaultAnalysis(): LLMCapabilityAnalysis {
  return {
    needsSpecialTool: false,
    toolName: '',
    toolType: 'pip',
    installCommand: '',
    githubSearchQuery: '',
    reason: '',
    hasToolLocally: true,
    requestedFormat: 'none',
    requestedAction: '',
    shouldGenerateFile: false,
  };
}

/**
 * Full autonomous flow:
 * 1. LLM analyzes request
 * 2. If needs tool and doesn't have it → search GitHub
 * 3. Install tool
 * 4. Return result
 */
export async function autonomousAcquireAndExecute(
  userMessage: string,
  language: 'ar' | 'en' = 'ar'
): Promise<{
  analysis: LLMCapabilityAnalysis;
  installed: boolean;
  installMessage: string;
  steps: string[];
}> {
  const steps: string[] = [];

  // Step 1: LLM analyzes the request
  steps.push('🧠 الموديل بيحلل طلبك...');
  const analysis = await analyzeCapabilityWithLLM(userMessage, language);
  steps.push(`التحليل: ${analysis.reason}`);

  if (!analysis.needsSpecialTool) {
    steps.push('لا يحتاج أداة خاصة');
    return { analysis, installed: false, installMessage: '', steps };
  }

  if (analysis.hasToolLocally) {
    steps.push(`✅ الأداة "${analysis.toolName}" متاحة محلياً`);
    return { analysis, installed: false, installMessage: 'متاح', steps };
  }

  // Step 2: Need to install the tool
  steps.push(`⚠️ الأداة "${analysis.toolName}" غير متاحة`);
  steps.push(`🔍 البحث في GitHub عن: ${analysis.githubSearchQuery}`);

  // Step 3: Search and install
  const { searchGitHubTools, installTool } = await import('./autonomous-agent');
  const searchResults = await searchGitHubTools(analysis.githubSearchQuery, 3);

  if (searchResults.length === 0) {
    // Try direct install with the command from LLM
    if (analysis.installCommand) {
      steps.push(`📦 محاولة التثبيت المباشر: ${analysis.installCommand}`);
      const tool = {
        repo: analysis.toolName,
        name: analysis.toolName,
        description: analysis.reason,
        url: '',
        installType: analysis.toolType as any,
        installCommand: analysis.installCommand,
        score: 0,
      };
      const result = await installTool(tool);
      steps.push(result.message);
      return { analysis, installed: result.success, installMessage: result.message, steps };
    }

    steps.push('❌ لم أجد الأداة');
    return { analysis, installed: false, installMessage: 'لم أجد الأداة', steps };
  }

  // Install best match
  const bestMatch = searchResults[0];
  steps.push(`📦 تثبيت ${bestMatch.name}...`);
  const installResult = await installTool(bestMatch);
  steps.push(installResult.message);

  return {
    analysis,
    installed: installResult.success,
    installMessage: installResult.message,
    steps,
  };
}
